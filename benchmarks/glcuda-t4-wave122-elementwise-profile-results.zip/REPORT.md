# Wave 122 elementwise profile

- GPU prefill: 19.259329 ms over 244 tokens = 12669.2 tok/s
- Stage sum: 17.935136 ms (0.931x GPU total)
- Attention bucket: 6.068544 ms
- FFN bucket: 11.270976 ms
- Glue subtotal: 2.369120 ms
- Next fusion candidate: ffn_silu_quant

| stage | ms | share of GPU total | calls | bytes read | macs |
|---|---:|---:|---:|---:|---:|
| `ffn_gate_up` | 4.952800 | 25.72% | 24 | 889061376 | 51042582528 |
| `ffn_down` | 4.297024 | 22.31% | 24 | 444530688 | 25521291264 |
| `attention` | 2.894112 | 15.03% | 24 | 5163024384 | 1285509120 |
| `ffn_silu_quant` | 1.546464 | 8.03% | 24 | 227868672 | 0 |
| `qkv` | 1.328032 | 6.90% | 24 | 125396992 | 6044516352 |
| `attn_out` | 0.848320 | 4.40% | 24 | 81887232 | 4701290496 |
| `lm_head` | 0.595616 | 3.09% | 1 | 144643072 | 136134656 |
| `attn_norm` | 0.487072 | 2.53% | 24 | 0 | 0 |
| `ffn_residual_norm_quant` | 0.421184 | 2.19% | 24 | 42061824 | 0 |
| `attn_out_quant` | 0.347968 | 1.81% | 24 | 20987904 | 0 |
| `attn_kv_write` | 0.163040 | 0.85% | 24 | 0 | 0 |
| `ffn_residual_add` | 0.053504 | 0.28% | 24 | 1748992 | 0 |