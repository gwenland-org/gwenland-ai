# Wave 131 fused SwiGLU production and ceiling

- Production A/B samples: 40 per arm, counterbalanced a+b
- Retained median: 18.587111 ms = 13127.4 tok/s
- Candidate median: 17.812217 ms = 13698.5 tok/s
- Speedup: 1.0435x
- Target 15k reached: False
- Decode P50 range: 209.138..211.002 tok/s
- Candidate profile GPU: 19.513344 ms = 12504.3 tok/s

| candidate stage | ms | share of GPU total | calls | bytes read | macs |
|---|---:|---:|---:|---:|---:|
| `ffn_gate_up` | 5.164768 | 26.47% | 24 | 889061376 | 51042582528 |
| `ffn_down` | 4.329856 | 22.19% | 24 | 444530688 | 25521291264 |
| `attention` | 3.007808 | 15.41% | 24 | 5163024384 | 1285509120 |
| `qkv` | 1.509472 | 7.74% | 24 | 125396992 | 6044516352 |
| `attn_norm` | 1.021280 | 5.23% | 24 | 0 | 0 |
| `attn_out` | 0.952480 | 4.88% | 24 | 81887232 | 4701290496 |
| `lm_head` | 0.606592 | 3.11% | 1 | 144643072 | 136134656 |
| `ffn_residual_norm_quant` | 0.501952 | 2.57% | 24 | 42061824 | 0 |
| `attn_out_quant` | 0.461504 | 2.37% | 24 | 20987904 | 0 |
| `attn_kv_write` | 0.378720 | 1.94% | 24 | 0 | 0 |
| `ffn_residual_add` | 0.063808 | 0.33% | 24 | 1748992 | 0 |
| `ffn_silu_quant` | 0.052640 | 0.27% | 24 | 227868672 | 0 |