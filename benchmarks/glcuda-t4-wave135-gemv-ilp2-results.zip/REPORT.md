# Wave 135 two-accumulator decode GEMV

- Decision: **reject**
- Decode P50: 215.484 -> 215.354 tok/s (-0.060%)
- Prefill P50: 15515.590 -> 15605.811 tok/s (+0.581%)
- Candidate sessions directional: True
- Registers/thread: 52; spills: 0 bytes
- Oracle: 50/50 tokens in all four sessions