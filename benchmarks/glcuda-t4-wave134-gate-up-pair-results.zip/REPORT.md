# Wave 134 paired gate/up decode GEMV

- Decision: **reject**
- Decode P50: 218.656 -> 217.726 tok/s (-0.425%)
- Prefill P50: 15930.468 -> 15936.215 tok/s (+0.036%)
- Candidate sessions directional: False
- Registers/thread: 49; spills: 0 bytes
- Oracle: 50/50 tokens in all four sessions