# Wave 133 captured decode graph profile

Diagnostic only: event nodes perturb the graph and are not retention authority.
- Control decode P50: 205.499 tok/s
- Instrumented decode P50: 100.128 tok/s
- Instrumentation slowdown: 2.0524x

| stage | median total ms | runs |
|---|---:|---:|
| `ffn_gate_up` | 1179.155233 | 2 |
| `attention` | 1039.451410 | 2 |
| `ffn_down` | 918.226164 | 2 |
| `qkv` | 677.987152 | 2 |
| `attn_prepare` | 512.779824 | 2 |
| `attn_out` | 495.150289 | 2 |
| `lm_head` | 385.085520 | 2 |
| `ffn_input` | 300.246064 | 2 |
| `ffn_activation` | 266.192720 | 2 |
| `attn_input` | 224.239985 | 2 |