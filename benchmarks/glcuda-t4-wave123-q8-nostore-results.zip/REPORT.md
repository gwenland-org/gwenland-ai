# Wave 123 Q8 no-store + stacked gate/up

- Production A/B samples: 40 per arm, counterbalanced a+b
- Retained median: 19.103201 ms = 12772.7 tok/s
- Candidate median: 18.333203 ms = 13309.2 tok/s
- Speedup: 1.0420x
- Target 15k reached: False
- Candidate profile GPU: 19.097313 ms = 12776.7 tok/s

| candidate stage | ms | share of GPU total | calls | bytes read | macs |
|---|---:|---:|---:|---:|---:|
| `ffn_gate_up` | 4.864064 | 25.47% | 24 | 889061376 | 51042582528 |
| `ffn_down` | 4.287040 | 22.45% | 24 | 444530688 | 25521291264 |
| `attention` | 2.923424 | 15.31% | 24 | 5163024384 | 1285509120 |
| `qkv` | 1.308448 | 6.85% | 24 | 125396992 | 6044516352 |
| `ffn_silu_quant` | 1.238368 | 6.48% | 24 | 227868672 | 0 |
| `attn_out` | 0.853824 | 4.47% | 24 | 81887232 | 4701290496 |
| `lm_head` | 0.593920 | 3.11% | 1 | 144643072 | 136134656 |
| `attn_norm` | 0.504576 | 2.64% | 24 | 0 | 0 |
| `ffn_residual_norm_quant` | 0.407520 | 2.13% | 24 | 42061824 | 0 |
| `attn_out_quant` | 0.356704 | 1.87% | 24 | 20987904 | 0 |
| `attn_kv_write` | 0.169568 | 0.89% | 24 | 0 | 0 |
| `ffn_residual_add` | 0.056928 | 0.30% | 24 | 1748992 | 0 |