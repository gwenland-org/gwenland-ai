# Wave 131 fused SwiGLU production and ceiling

- Production A/B samples: 40 per arm, counterbalanced a+b
- Retained median: 18.581367 ms = 13131.4 tok/s
- Candidate median: 18.120479 ms = 13465.4 tok/s
- Speedup: 1.0254x
- Target 15k reached: False
- Decode P50 range: 207.478..214.998 tok/s
- Candidate profile GPU: 21.208832 ms = 11504.6 tok/s

| candidate stage | ms | share of GPU total | calls | bytes read | macs |
|---|---:|---:|---:|---:|---:|
| `ffn_gate_up` | 5.731136 | 27.02% | 24 | 889061376 | 51042582528 |
| `ffn_down` | 4.796608 | 22.62% | 24 | 444530688 | 25521291264 |
| `attention` | 3.348032 | 15.79% | 24 | 5163024384 | 1285509120 |
| `qkv` | 1.627392 | 7.67% | 24 | 125396992 | 6044516352 |
| `attn_norm` | 1.048064 | 4.94% | 24 | 0 | 0 |
| `attn_out` | 1.042976 | 4.92% | 24 | 81887232 | 4701290496 |
| `lm_head` | 0.609312 | 2.87% | 1 | 144643072 | 136134656 |
| `ffn_residual_norm_quant` | 0.539008 | 2.54% | 24 | 42061824 | 0 |
| `attn_out_quant` | 0.497536 | 2.35% | 24 | 20987904 | 0 |
| `attn_kv_write` | 0.400256 | 1.89% | 24 | 0 | 0 |
| `ffn_residual_add` | 0.062176 | 0.29% | 24 | 1748992 | 0 |
| `ffn_silu_quant` | 0.050048 | 0.24% | 24 | 227868672 | 0 |