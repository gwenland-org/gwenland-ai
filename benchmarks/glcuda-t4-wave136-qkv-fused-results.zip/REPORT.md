# Wave 136 fused QKV decode grid

- Decision: **retain**
- Decode P50: 216.613 -> 223.628 tok/s (+3.238%)
- Prefill P50: 15858.150 -> 15744.514 tok/s (-0.717%)
- Candidate sessions directional: True
- Registers/thread: 34; spills: 0 bytes
- Oracle: 50/50 tokens in all four sessions